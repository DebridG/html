<?php
class dl_simply_debrid_com extends Download {
	public function PreLeech($url){

	}
		
	public function CheckAcc($cookie){
		global $user;
		global $pass;
		
		if($cookie != "") return array(false, "Not Support Cookie !!!");
		
		$data = $this->lib->curl('http://simply-debrid.com/api.php?login=2&u='.urlencode($user).'&p='.urlencode($pass).'', '', '', 0);
		list($status, $username, $expired) = explode(";", $data);
		
		if($status = "1") return array(true, "Vaid until ".$expired);
		elseif($status = "0") return array(false, "accfree");
		else return array(false, "accinvalid");
		
	}
	
	public function Login($user, $pass){
		$data = $this->lib->curl('http://simply-debrid.com/api.php?login=1&u='.urlencode($user).'&p='.urlencode($pass).'', '', '', 0);
		if($data = "02: loggin success") {
			return "";
		}
	}
    public function Leech($url) {	
		global $user;
		global $pass;
		
		$cookie = $this->lib->cookie;
		$data = $this->lib->curl("http://real-debrid.com/ajax/unrestrict.php?link=".urlencode($url)."&password=&remote=0&time=".time(),$cookie,'',0);
		$page = json_decode($data, true);
		if (stristr($data,'Dedicated server detected'))  {
			$this->error("<font color=red><b>Dedicated server detected, you are not allowed to generate a link !</b></font>", true, false);
		}
		elseif(isset($page['error']) && $page['error'] != '0')  $this->error('<font color=red>'.$page['message'].'</font>', true, false);
		else return trim($page['generated_links'][0][2]);
		return false;
    }

}

/*
* Open Source Project
* Vinaget by ..::[H]::..
* Version: 2.7.0
* Simply-Debrid Download Plugin by Tieuholuckyboy (13/09/2014)
/
?>
?>