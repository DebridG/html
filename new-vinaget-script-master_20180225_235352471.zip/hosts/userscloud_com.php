<?php

class dl_userscloud_com extends Download {

   public function FreeLeech($url) {
      $data = $this->lib->curl($url, "", "");
      if (strpos($data, "<Title>Download") === false) $this->error("dead", true, false, 2);
      else {
         $post = $this->parseForm($this->lib->cut_str($data, '<form name="F1"', '</form'));
         $data = $this->lib->curl($url, "", $post);
         if ($this->isredirect($data)) return $this->redirect;
      }
      return false;
   }

}
?>