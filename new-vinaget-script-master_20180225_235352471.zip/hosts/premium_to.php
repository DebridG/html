<?php
class dl_premium_to extends Download {

	public function Login($user, $pass){
		$data = $this->lib->curl("http://premium.to/api/getauthcode.php?username=".urlencode($user)."&password=".urlencode($pass)."", "", "");
		if(stristr($data, "HTTP/1.1 200 OK")) {
			preg_match_all("/.*?([a-zA-z0-9])\z/", $data, $authcode);
			return "authcode=".$authcode[0][0];
		}
		return false;
	}	
	public function CheckAcc($cookie){
		$data = $this->lib->curl("http://premium.to/api/traffic.php?".$cookie, "", "");
		preg_match_all("/.*?([0-9]*)\z/", $data, $match);
		if(stristr($data, "HTTP/1.1 420")) {
			return array(true, $match[0][0]);
		}
		else {
			return array(true, "Traffic left: ".round($match[0][0]/1073741824, 2)." GB");
		}
	
	}
        public function Leech($url) {	
		preg_match("/=(.*?);/", $this->lib->cookie, $authcode);
		$data = $this->lib->curl("http://premium.to/api/getfile.php?authcode=".$authcode[1]."&link=".urlencode($url), "", "");
		if(stristr($data, "HTTP/1.1 420")) {
			preg_match_all("/.*?([a-zA-z0-9])\z/", $data, $error);
			$this->error($error[0][0], true, false);
		} else {
			preg_match('/Location: (.*)/',$data,$match);
			return trim($match[1]);
		}
       }

}

/*
* Open Source Project
* Vinaget by ..::[H]::..
* Version: 2.7.0
* Premium.to Download Plugin by Tieuholuckyboy (22/7/2014)
/
?>
?>