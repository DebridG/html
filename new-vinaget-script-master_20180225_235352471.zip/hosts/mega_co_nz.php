<?php
// referer to mega_nz.php
?>