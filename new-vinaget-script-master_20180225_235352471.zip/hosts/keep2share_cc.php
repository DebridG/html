<?php
// referer to k2s_cc.php
?>