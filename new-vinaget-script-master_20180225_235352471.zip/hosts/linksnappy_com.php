<?php

class dl_linksnappy_com extends Download {
    
    public function CheckAcc($cookie){
        $data = $this->lib->curl('https://linksnappy.com/myaccount',$cookie,'');	
		if(strstr($data, 'Elite üye şu tarihe kadar:')) {
			$s=$this->lib->cut_str($data,"Elite üye şu tarihe kadar:</strong>","<br /><strong>");
			return array(true,$s);
        }
		elseif(strstr($data, 'href="/logout">')) {
			return array(true,"accfree");
        }
		else return array(false, "accinvalid");
    }
    
    public function Login($user, $pass){
		$data = $this->lib->curl("http://linksnappy.com/members/index.php?act=login","","username=".urlencode($user)."&password=".urlencode($pass)."&submit=Login");
		return $this->lib->GetCookies($data);
    }
	
    public function Leech($url) {
		$time = time();
		$pass="";
		$data = $this->lib->curl('http://gen.linksnappy.com/genAPI.php?callback=jQuery152034288353948601724_'.$time.'&genLinks={"link"+:+"'.$url.'",+"linkpass"+:+"'.$pass.'"}',$this->lib->cookie,'');	
		if(preg_match('%generated":"(.*)"%U', $data, $linkpre)){
			$link=str_replace("\\","",trim($linkpre[1]));
			
			return $link;
		}
    }
	
}

/*
* Open Source Project
* Vinaget by ..::[H]::..
* Version: 2.7.0
* linksnappy.com Plugin by EvilKİNGGG
* Downloader Class By [FZ]
*/
?>