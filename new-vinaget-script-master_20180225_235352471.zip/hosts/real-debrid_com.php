<?php
class dl_real_debrid_com extends Download {
	public function PreLeech($url){

	}
		
	public function CheckAcc($cookie){
		$page = $this->lib->curl('http://real-debrid.com/api/account.php', $cookie,'',0);
		
			if(stristr($page, '<type>premium</type>')) return array(true, "Until ".$this->lib->cut_str($page, '<expiration-txt>', '</expiration-txt>'));
		elseif(stristr($page, '<type>free</type>')) return array(false, "accfree");
		else return array(false, "accinvalid");
		
	}
	
	public function Login($user, $pass){
		$page = $this->lib->curl('https://real-debrid.com/ajax/login.php?lang=en&user='.urldecode($user).'&pass='.urldecode($pass).'','','',0);
		$data = json_decode($page, true);
		if($data['message'] == 'OK') {
			return $data['cookie'];
		} 
	}
    public function Leech($url) {	
		$cookie = $this->lib->cookie;
		$data = $this->lib->curl("http://real-debrid.com/ajax/unrestrict.php?link=".urlencode($url)."&password=&remote=0&time=".time(),$cookie,'',0);
		$page = json_decode($data, true);
		if (stristr($data,'Dedicated server detected'))  {
			$this->error("<font color=red><b>Dedicated server detected, you are not allowed to generate a link !</b></font>", true, false);
		}
		elseif(isset($page['error']) && $page['error'] != '0')  $this->error('<font color=red>'.$page['message'].'</font>', true, false);
		else return trim($page['generated_links'][0][2]);
		return false;
    }

}

/*
* Open Source Project
* Vinaget by ..::[H]::..
* Version: 2.7.0
* Tenlua.vn Download Plugin by Tieuholuckyboy (22/7/2014)
/
?>
?>