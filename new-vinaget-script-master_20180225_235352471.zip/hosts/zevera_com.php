<?php
class dl_zevera_com extends Download {

	public function Login($user, $pass){
		return ".ASPNETAUTH=0101289A5F1D6D7AD108FE285A70F15A7ED10801116D0069006100740061003000310040006C0069006200650072006F002E0069007400064D0065006D00620065007200012F00FF";
	}	
	public function CheckAcc($cookie){
		
		return array(true, "");
	
	}
    public function Leech($url) {	
		$cookie = ".ASPNETAUTH=0101289A5F1D6D7AD108FE285A70F15A7ED10801116D0069006100740061003000310040006C0069006200650072006F002E0069007400064D0065006D00620065007200012F00FF";
		$url = "http://zevera.com/Member/download.ashx?retry=1&ourl=".urlencode($url);
		$data = $this->lib->curl($url, $cookie, '');
		preg_match('/ocation: (.*)/',$data,$match);
		if(!strpos($match[1], "member/systemmessage.aspx")) {
			return trim($match[1]);
		} else {
			echo $this->lib->curl($match[1], $cookie, '', 1);
			return false;
		}
    }

}

/*
* Open Source Project
* Vinaget by ..::[H]::..
* Version: 2.7.0
* Tenlua.vn Download Plugin by Tieuholuckyboy (22/7/2014)
/
?>
?>