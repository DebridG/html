New Vinaget Script 3.3 LTSB - Developed by LTT♥  
Referer from: https://github.com/giaythuytinh176/vinaget-script   
Contact email for request plugin updates: lethanhtuan2897@gmail.com  

######################################  
How to use:  
CHMOD the folder "data" to 777  
CHMOD file "data/account.dat" to 666.  
CHMOD file "data/config.dat" to 666.  
CHMOD file "data/cookie.dat" to 666.  
CHMOD file "data/online.dat" to 666.  
CHMOD file "data/log.txt" to 666.  
CHMOD file "datafile_descrypt.html" to 666.  
Password default: admin  
######################################  
  
Home page: http://vinaget.us  
Version: VinaGet 2.7.0 Final
  
Description:  
Vinaget is script generator premium link that allows you to download files instantly and at the best of your Internet speed.  
Vinaget is your personal proxy host protecting your real IP to download files hosted on hosters like RapidShare, bitshare.com , hotfile...  
You can now download files with full resume support from filehosts using download managers like IDM etc  
Vinaget is a Free Open Source, supported by a growing community.  
Code LeechViet by VinhNhaTrang  
Developed by ..:: [H] ::.., [FZ]  
  
Basic Features:  
Admin Panel  
Proxy Support  
Easy to get multi link and make list in one go.  
Fast download speed with vinaget script.  
Support downloads from more than 30 filehost  
Use Rewrite URL  
Make plugin independent of release (easy fix and update plugin)  
enable/disable all user can see list files.  
enable/disable other people can see your file in the list files  
enable/disable other people can download your file.  
enable/disable all user can use check account.  
enable/disable show link for cbox  
enable/disable check link 3x,porn...  
Multi password login  
Limit file size  
link checker  
3x, porn checker  
Account checker  
Donate Account  
Account Management  
Cookie Management  
Limit load file for 1 IP  
Limit file per mins  
Limit load file per time  
Auto del file per time  
Max total jobs in this host  
Max server load (linux)  
